﻿public interface IDamageable
{
    void TakeDamage(int amount, bool isCrit = false);
}