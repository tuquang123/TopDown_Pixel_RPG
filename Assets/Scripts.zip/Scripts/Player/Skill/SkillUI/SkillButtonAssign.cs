﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SkillButtonAssign : MonoBehaviour
{
    public Button button;
    public Image icon;
    public TextMeshProUGUI nameText;
}